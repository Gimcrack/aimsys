$(document).ready( function() {
	$frm = $('.main-content.active .part.active #frm_editor');
	//$("input:not(':hidden'),select",$frm).attr('disabled',true);
		
	$('button',$target).button();
		
});