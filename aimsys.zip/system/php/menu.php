<div id="top-menu">
	<ul id="top-menu-ul" class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
	  <li class="ui-state-active ui-corner-bottom"><a onclick="logout();" href="#" title="logout">Logout</a></li>
	  <li class="ui-state-default ui-corner-bottom"><a href="#">Profile</a></li>
	  <li class="ui-state-default ui-corner-bottom"><a href="#ui-tabs-2">Help</a></li>
	</ul>
</div>
 
<div id="main-menu"> 
	<ul id="menu-ul" class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
	  <li class="ui-state-default ui-corner-top ui-tabs-selected ui-state-active"><a href="#ui-tabs-1">Users</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-2">Groups</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-3">Inventory</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-4">Maintenance</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-5">Operations</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-6">Fleet</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-7">Corrections</a></li>
	  <li class="ui-state-default ui-corner-top"><a href="#ui-tabs-8">History</a></li>
	</ul>
</div>


