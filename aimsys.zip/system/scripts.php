<?php

$scripts = array(
"jquery.js",
"jquery-ui.js",
"functions.js",
"jquery.loadmask.min.js",
"jquery.multiselect.js",
"jquery.multiselect.filter.js",
"classes/class.tab.js",
"prettyprint.js",
"validate_frm.js",
"jquery.countdown.min.js",
"jquery.noty.js",
"jquery.noty.top.js",
"jquery.noty.topCenter.js",
"jquery.noty.center.js",
"jquery.noty.bottom.js",
"jquery.noty.default.js",
"jquery.noty.bottomLeft.js",
"jquery.noty.inline.js",
);
echo document::_addScript($scripts);

//other scripts

$basedir = "includes/easyui/plugins/";
$scripts = array(
//"../jquery.easyui.min.js",
"jquery.menu.js",
"jquery.linkbutton.js",
"jquery.menubutton.js",
"jquery.splitbutton.js"
);

echo document::_addScript($scripts,true,$basedir);


?>