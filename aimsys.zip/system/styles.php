<?php

$styles = array(
"style-ie.css",
"jquery-ui.css",
"jqueryui-smoothness.css",
"jquery.loadmask.css",
"jquery.multiselect.css",
"jquery.multiselect.filter.css",
"jquery.noty.buttons.css",
"style.css",
//"jquery.countdown.css"
);

echo document::_addStyle($styles);


//other scripts

$basedir = "includes/easyui/themes/";
$styles = array(
"icon.css",
"default/splitbutton.css",
"default/menubutton.css",
"default/linkbutton.css",
"default/menu.css",
"default/searchbox.css",
"default/easyui.css",
);

echo document::_addStyle($styles,true,$basedir);

echo document::_addStyle("style-small.css",NULL,NULL,"screen and (max-width:1500px)");

?>