<?php


?>

<link rel="stylesheet" href="../includes/css/style.css">

<div class="table">

	<div class="row header">
		<div class="cell">&nbsp;</div>
	</div>
	
	<div class="clear"></div>

	<div class="row header">
		<div class="cell">ID</div>
		<div class="cell">Username</div>
		<div class="cell">First Name</div>
		<div class="cell">Last Name</div>
		<div class="cell">Email Address</div>
	</div>
	
	<div class="clear"></div>

	<div class="row">
		<div class="cell">3</div>
		<div class="cell">username</div>
		<div class="cell">John</div>
		<div class="cell">Doe</div>
		<div class="cell">email@address.com</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="row">
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="row">
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="row">
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
		<div class="cell">&nbsp;</div>
	</div>
	
	<div class="clear"></div>
	
	<div class="row footer">
		<div class="cell">&nbsp;</div>
	</div>
	
	<div class="clear"></div>
	
</div>