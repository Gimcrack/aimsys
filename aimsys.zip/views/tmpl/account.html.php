
<div id="content-header">Manage Account</div>
<div id="content-header-bar"></div>

<div id="content-body">HTML Template</div>