
<div id="content-header">Home</div>
<div id="content-header-bar"></div>

<div id="content-body">Home HTML Template</div>