<div id="top">
	<div id="top-logo"></div>
	<div id="top-text">Aircraft Inventory & Maintenance System</div>
	<div id="tab-bar">
		<ul>
			<li id="login" class="active ui-corner-top">Login</li>
		</ul>
	</div>
</div>
<div id="main" class="no-left ui-corner-bottom shadow">
	
    <div id="content-header" class="no-left">Login</div>
    <div id="content-header-bar" class="no-left"></div>

	<div style="height:100px;"></div>

	<div class="form-container ui-corner-all">
	
	<form id="frm_login" name="frm_login" action="index.php" method="POST" >
		<table>
		<tr><th colspan="2">Please Login</th></tr>
		<tr><td><label class="required-label" For="username">Username : </label>&nbsp;</td><td><input type="text" name="use_username" id="username" class="required-input" validType="Anything" /><input type="hidden" name="frm_name" id="frm_name" value="frm_login" class="optional-input" /></td></tr>
		
		<tr><td><label class="required-label" For="password">Password : </label>&nbsp;</td><td><input type="password" name="use_password" id="password" class="required-input" validType="Anything" /><button type="button" name="btn_submit" id="btn_submit" onClick="validate_submit_form(this.form)" />Go</button></td></tr>
		<tr><th colspan="2">Copyright &copy - All Rights Reserved</th></tr>
		</table>
	</form>
	
	</div>
	
	<?=$message?>
	

</div>