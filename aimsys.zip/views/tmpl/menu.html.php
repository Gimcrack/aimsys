<ul class="ui-corner-all">
	<li class="ui-corner-all" id="home" tt="Opens Home Tab"><a href="index.php?controller=tab&option=home&view=home" ></a></li>
	<li class="ui-corner-all" id="inventory" tt="Opens Inventory Tab"><a href="index.php?controller=qv&view=parts|part_templates|part_categories"></a></li>
    <li class="ui-corner-all" id="maintenance" tt="Opens Maintenance Tab"><a href="index.php?controller=qv&view=maintenance|maintenance_templates"></a></li>
    <li class="ui-corner-all" id="fleet" tt="Opens Fleet Tab"><a href="index.php?controller=qv&view=fleet|fleet_templates|locations"></a></li>
    <li class="ui-corner-all" id="records" tt="Opens Records Tab"><a href="index.php?controller=qv&view=history"></a></li>
	<li class="ui-corner-all" id="users" tt="Opens Users Tab"><a href="index.php?controller=qv&view=users|groups|locations"></a></li>
    <li class="ui-corner-all" id="search" tt="Opens Search Tab"><a href="index.php?controller=tab&option=search"></a></li>
    <!--Hidden Menu Links-->
    <li class="ui-corner-all" id="sulogin" style="display:none"><a href="index.php?controller=tab&option=su"></a></li>
    <li class="ui-corner-all" id="manageaccount" style="display:none"><a href="index.php?controller=tab&option=account"></a></li>
</ul>