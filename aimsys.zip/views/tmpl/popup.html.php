<div class="content-body">
    <div id="details" class="active part">
        <?=$editor_html;?>
    </div>
    
</div>