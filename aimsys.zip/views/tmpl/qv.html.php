
<div id="content-header"><?=ucfirst($content_header);?></div>
<div id="content-header-bar">
	<ul>
    	<?=$subtabs_html;?>
    </ul>

</div>

<div class="content-body">
	<?=$content_html;?>
</div>