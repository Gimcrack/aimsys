
<div id="content-header">Search</div>
<div id="content-header-bar"></div>

<div id="content-body">Search HTML Template</div>