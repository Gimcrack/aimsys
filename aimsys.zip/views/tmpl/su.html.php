
<div id="content-header">Super User</div>
<div id="content-header-bar">
	<ul>
    	<?=$tabs_html;?>  
    </ul>

</div>

<div class="content-body">

	<?=$html;?>
		


</div>