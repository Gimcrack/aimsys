/* jQuery Form Validation */

var state_abbrevs = [	"AL","AK","AS","AZ","AR",
						"CA","CO","CT","DE","DC",
						"FM","FL","GA","GU","HI",
						"ID","IL","IN","IA","KS",
						"KY","LA","ME","MH","MD",
						"MA","MI","MN","MS","MO",
						"MT","NE","NV","NH","NJ",
						"NM","NY","NC","ND","MP",
						"OH","OK","OR","PW","PA",
						"PR","RI","SC","SD","TN",
						"TX","UT","VT","VI","VA",
						"WA","WV","WI","WY"];

var validate_form_err_msg = {
'Anything'		: 'Please enter something in the field.',
'file' 			: 'Please enter a file in the field.',
'Number' 		: 'Please enter a number in the field.',
'Integer' 		: 'Please enter an integer in the field.',
'Email Address' : 'Please enter an email address in the field.',
'Zip Code'		: 'Please enter a valid zip code in the field.',
'Phone Number'	: 'Please enter a valid 10-digit phone number in the field.',
'US State'		: 'Please enter a valid US State abbreviation.',
'checkbox'		: 'Please check the box',
'radio'			: 'Please check one of the options.',
'select'		: 'Please select a value from the dropdown.',
'min>='			: 'Field value must be at least [val] characters long.',
'max<='			: 'Field value must be at most [val] characters long.',
'min_val>='		: 'Field value must be >= [val].',
'max_val<='		: 'Field value must be <= [val].',
'exact=='		: 'Field value must be exactly [val] characters long.',
'between=='		: 'Field value must be between [val]',
'date_gt_'		: 'Date must be after [val].',
'date_lt_'		: 'Date must be before [val].',
'field=='		: 'Field must match [val]',
'default'		: 'Please correct this field.'
}

function validate_form(frm) {
	$frm = $(frm); 
	var val_error = false;
	var val_msg = "";
	var prev_rad_name = "";
	$elms = $('.required-input',$frm); 
	$.each($elms, function($i,$elm) {
		$elm_valid = validate_field( $(this) )
		if ( $elm_valid ) { // field is invalid
			removeError( $(this) );
			//console.log($(this).attr('name') + ' : valid');
		}
		else {
			raiseError( $(this) );
			//onconsole.log($(this).attr('name') + ' : error');
			val_error = true;
		}
	}); 
	if (val_error) {
		return false;
	} else { 
		return true;
	}
}

function validate_field($elm) {
	
	var $error_index;
	if ($elm.prop('disabled') ) { return true; };
	
	cat = ( $elm.attr('validType') ) ? $elm.attr('validType') : ' ';
	switch (cat) {
		case 'Anything' : 			case 'file' : 														$elm_valid = Boolean( $elm.val().trim() );				break;
		case 'Number' :				re = /[^0-9.]+/;													$elm_valid = Boolean( !$elm.val().match(re) && $elm.val().trim().length > 0 );			break;
		case 'Integer' :			re = /[^0-9]+/;														$elm_valid = Boolean( !$elm.val().match(re) && $elm.val().trim().length > 0 );			break;
		case 'Email Address' :		re = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;	$elm_valid = Boolean( $elm.val().match(re) );			break;
		case 'Zip Code' :			re = /^\d{5}([\-]\d{4})?$/; 										$elm_valid = Boolean( $elm.val().match(re) );			break;
		case 'Phone Number' :		re = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;						$elm_valid = Boolean( $elm.val().match(re) );			break;
		case 'US State'	:																				$elm_valid = Boolean( $elm.val().toUpperCase() in oc(state_abbrevs) );	break;
		case 'checkbox' :																				$elm_valid = $elm.prop('checked') ;						break;
		case 'radio' :				$name = $elm.attr('name'); 											$elm_valid = Boolean($('[name='+$name+']:checked').size() ); 		break;
		case 'select' :				                        											$elm_valid = Boolean( Number($elm.prop('selectedIndex') ) ); 		break;
			
		default :
			if ($elm.attr('type').indexOf('select') != -1) { // select-one or select-multiple
				$elm_valid = Boolean( $elm.prop('selectedIndex') );
			}
			else if ($elm.attr('type').indexOf('checkbox') != -1) { // checkbox
				$elm_valid = Boolean( $elm.prop('checked') );
			}
			else if (cat.indexOf('min>=') != -1) { // minimum characters.
				min_chars = Number(cat.replace('min>=',''));
				$elm_valid = Boolean($elm.val().length >= min_chars);
			}
			else if (cat.indexOf('max<=') != -1) { // maxiumum characters.
				max_chars = Number(cat.replace('max<=',''));
				$elm_valid = Boolean($elm.val().length <= max_chars);
			}
			else if (cat.indexOf('min_val>=') != -1) { // minimum value.
				min_val = eval(cat.replace('min_val>=',''));
				$elm_valid = Boolean( Number($elm.val() ) >= min_val);
			}
			else if (cat.indexOf('max_val<=') != -1) { // maximum value.
				max_val = eval(cat.replace('max_val<=',''));
				$elm_valid = Boolean( Number($elm.val() ) <= max_val);
			}
			else if (cat.indexOf('exact==') != -1) { // exact number of characters.
				ex_chars = eval(cat.replace('exact==','') );
				$elm_valid = Boolean($elm.val().length == ex_chars);
			}
			else if (cat.indexOf('between==') != -1) { // between two values
				lo_hi = cat.replace('between==','');
				lo = 1*lo_hi.split(',')[0];
				hi = 1*lo_hi.split(',')[1];
				$val = Number($elm.val() );
				$elm_valid = Boolean( $val >= lo && $val <= hi);
			}
			else if (cat.indexOf('date_gt_') != -1 || cat.indexOf('date_lt_') != -1 ) { // field must be greater/less than date.
				
				date2 = cat.replace('date_gt_','').replace('date_lt_','');
				date2_val = $(date2).val();
				
				// Calculate date2 - YYYY-MM-DD HH:II
				var yr = date2_val.substr(0,4)
				var mo = Number(date2_val.substr(5,2)-1);
				var da = date2_val.substr(8,2);
				var hr = date2_val.substr(11,2);
				var mn = date2_val.substr(14,2);
				var date2 = new Date (yr,mo,da,hr,mn);
				//alert(yr + ' ' + mo + ' ' + da + ' ' + hr + ' ' + mn);
				
				date1_val = $elm.val();
				// Calculate date1
				var yr = date1_val.substr(0,4)
				var mo = eval(date1_val.substr(5,2)-1);
				var da = date1_val.substr(8,2);
				var hr = date1_val.substr(11,2);
				var mn = date1_val.substr(14,2);
				var date1 = new Date (yr,mo,da,hr,mn);
				//alert(yr + ' ' + mo + ' ' + da + ' ' + hr + ' ' + mn);
				
				$is_gt = Boolean(cat.indexOf('date_gt_') != -1);
				$elm_valid = ($is_gt) ? Boolean(date1 > date2 ) : Boolean(date2 > date1);
			} 
			else if (cat.indexOf('field==') != -1) { // field must match other field.
				pw1_name = cat.replace('field==','');
				temp_form = $elm.closest('form');
				$pw1 = $(":input[name='" + pw1_name + "']",temp_form); 
				$elm_valid = Boolean($elm.val() == $pw1.val() );
			}
			else { // must be in list.
				//alert(elm.type);
				var patterns = cat.toLowerCase().split('|');
				$elm_valid = Boolean($elm.val().toLowerCase() in oc(patterns) )
			}
		break;
	} // end switch
	return $elm_valid;
}


function isArray(obj) {
  if (obj.constructor.toString().indexOf("Array") == -1)
      return false;
   else
      return true;
}

function oc(arrayOrArgs)
{
 var o = {};
 var a = (isArray(arrayOrArgs)) ? arrayOrArgs : arguments;
  for(var i=0;i<a.length;i++)
  {
    o[a[i]]='';
  }
  return o;
}

function raiseError($elm) {
	$elmid = $elm.attr('id');
	$label = $("label[for='"+$elmid+"']").html();
	$elm.addClass('ui-state-error');
	$cat = ( $elm.attr('validType') ) ? $elm.attr('validType') : ' ';
	$err_index = -1;
	$.each(validate_form_err_msg, function($i,$val) {		
		if ($cat.indexOf($i) != -1) {
			$err_index = $i;
		}
	});
	if ($err_index == -1) {
		$err_index = 'default';
	}
	$err_msg = $label + ' ' + validate_form_err_msg[$err_index];
	$search = '[val]';
	$replace = $cat.replace($err_index,'');
	$err_msg = $err_msg.replace($search,$replace);
	noty_message($err_msg,'error');
}
function removeError($elm) {
	$elm.removeClass('ui-state-error');
	$elm.parent().parent().find('td').eq(2).remove();
}

/**
 *  Format phone numbers
*/
function formatPhone(phonenum) {
    var regexObj = /^(?:\+?1[-. ]?)?(?:\(?([0-9]{3})\)?[-. ]?)?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (regexObj.test(phonenum)) {
        var parts = phonenum.match(regexObj);
        var phone = "";
        if (parts[1]) { phone += "(" + parts[1] + ") "; }
        phone += parts[2] + "-" + parts[3];
        return phone;
    }
    else {
        //invalid phone number
        return phonenum;
    }
}

/**
 * Format postal code
*/
function formatZip(z) {
    z = z.replace(/[^0-9-]/, "");
	if (/^\d{6}$/.test(z)) {
		z = z.substring(0,5) + "-" + z.substring(5);
		return z;
	}
	else {
		return z.substring(0,10);
	}
}

function formatNumber(z) {
	if ( isNaN(parseFloat(z)) ) {
		return 0;
	}
	else {
		return parseFloat(z);
	}
}

function formatInteger(z) {
   return z.replace(/[^0-9]/, "");
}

function formatUC(z) {
	return z.toUpperCase()
}

function revalidate_field($elm) {
	$elm_valid = validate_field($elm)
	if ( $elm_valid ) { // field is invalid
		removeError($elm);
	}
	else {
		raiseError($elm);
	}
}
